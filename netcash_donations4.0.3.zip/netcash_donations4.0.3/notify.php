<?php
// Include WordPress environment to access DB constants and WP functions
require_once( $_SERVER['DOCUMENT_ROOT'] . '/wp-load.php' ); // Adjust path as needed

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Capture the Notify data
    $transactionAccepted = $_POST['TransactionAccepted'] ?? null;
    $reference = $_POST['Reference'] ?? null;
    $amount = $_POST['Amount'] ?? null; // Capture the amount
    $recurringFlag = $_POST['RecurringFlag'] ?? null; // Flag for recurring donations
    $donor_name = $_POST['m4'] ?? ''; // Capture donor name from the form (assuming it's passed in 'm4')

    // Debugging output - Check if we receive POST data correctly
    if (is_null($transactionAccepted) || is_null($reference)) {
        die('Missing required POST data.');
    }

    // Access the global $wpdb object to work with the database
    global $wpdb;
    $table_name = $wpdb->prefix . 'donor_gate_donations';

    // Define transaction status
    $status = ($transactionAccepted === 'true') ? 'completed' : 'failed';

    // Check if this is a recurring donation
    if ($recurringFlag === 'true') {
        // Recurring donation: Insert a new record for each payment
        $wpdb->insert($table_name, [
            'p2' => $reference,
            'amount' => $amount,
            'status' => $status,
            'transaction_date' => current_time('mysql', 1),
            'donor_name' => $donor_name // Store the donor name
        ]);

        if ($status === 'completed') {
            send_thank_you_email($reference, $amount, $donor_name); // Send thank-you email with donor's name
        }
        echo 'Recurring transaction recorded successfully';
    } else {
        // Non-recurring donation: Update the status of the existing transaction
        $wpdb->update(
            $table_name,
            ['status' => $status],
            ['p2' => $reference]
        );

        if ($status === 'completed') {
            send_thank_you_email($reference, $amount, $donor_name); // Send thank-you email with donor's name
        }
        echo 'Status updated successfully';
    }
} else {
    header("HTTP/1.1 405 Method Not Allowed");
    echo "Request method not allowed.";
}

// Function to send thank-you email
function send_thank_you_email($reference, $amount, $donor_name) {
    // Email configuration
    $from_email = get_option('donor_gate_email_from', get_bloginfo('admin_email'));
    $donation = $GLOBALS['wpdb']->get_row(
        $GLOBALS['wpdb']->prepare("SELECT * FROM {$GLOBALS['wpdb']->prefix}donor_gate_donations WHERE p2 = %s", $reference)
    );

    if (!$donation) {
        return; // Stop if no donation found
    }

    $to_email = $donation->email_address;
    $subject = 'Netcash Donation Confirmation';

    // Define the email template with placeholders for name and amount
    $message_template = get_option('donor_gate_email_message', 'Dear {name},<br><br>Thank you for your donation of R{amount}. Your support is appreciated!');

    // Replace placeholders with dynamic data (donor's name and amount)
    $message = str_replace(['{name}', '{amount}'], [$donor_name, $amount], $message_template);

    // Image URL for the header
    $image_url = 'https://netcash.co.za/wp-content/uploads/2024/11/Donations.png';

    // Create the HTML content with the image, structured message, and signature
    $html_content = "
    <html>
    <head>
        <style>
            /* Inline styling */
            body {
                font-family: Arial, sans-serif;
            }
            img.header-image {
                max-width: 100%;
                height: auto;
            }
            .message-content {
                margin-top: 20px;
                line-height: 1.6;
            }
            .signature {
                margin-top: 30px;
                font-style: italic;
            }
        </style>
    </head>
    <body>
        <div>
            <!-- Header Image -->
            <img src='$image_url' class='header-image' alt='Thank You for Your Donation'>

            <!-- Message Content -->
            <div class='message-content'>
                <p>$message</p>
            </div>

            
        </div>
    </body>
    </html>
    ";

    // Set headers with "From" name as "Netcash Donations"
    $headers = [
        'Content-Type: text/html; charset=UTF-8',
        'From: Netcash Donations <' . $from_email . '>', // "Netcash Donations" as the sender name
        'Reply-To: ' . $from_email // Optional: Reply-To header
    ];

    // Send the email
    wp_mail($to_email, $subject, $html_content, $headers);
}

?>
