<?php
/*
Template Name: Cancel Subscription
*/

// Include WordPress environment
require_once('../../../wp-load.php');

// Check if the current user has sufficient permissions
if (!current_user_can('manage_options')) {
    wp_die('Unauthorized access.');
}

// Validate nonce for security
if (!isset($_GET['_wpnonce']) || !wp_verify_nonce($_GET['_wpnonce'], 'donor_gate_cancel_subscription_' . $_GET['reference'])) {
    wp_die('Invalid request.');
}

// Get the reference and validate
$reference = sanitize_text_field($_GET['reference']);
if (empty($reference)) {
    wp_die('Missing reference number.');
}

// Netcash service endpoint
$wsdl = 'https://ws.netcash.co.za/PayNow/PayNow.svc?wsdl';

// Fetch the subscription details from the database
global $wpdb;
$donation = $wpdb->get_row($wpdb->prepare("SELECT * FROM {$wpdb->prefix}donor_gate_donations WHERE p2 = %s", $reference));

if (!$donation) {
    wp_die('Invalid reference number.');
}

// Prepare the parameters for the SOAP request
$params = [
    'M1' => get_option('donor_gate_m1_key'),  // Service key from plugin settings
    'P2' => $reference,
    'M17' => '999',
    'M18' => '1',
    'M19' => date('Ymd'),
    'M20' => $donation->amount,
    'Active' => true,
];

$response_message = '';
$response_class = '';

try {
    // Initialize SOAP client
    $client = new SoapClient($wsdl, ['trace' => true]);

    // Call the UpdateSubscriptions method
    $response = $client->UpdateSubscriptions($params);

    // Debugging output
    error_log('SOAP Request: ' . $client->__getLastRequest());
    error_log('SOAP Response: ' . $client->__getLastResponse());

    // Validate the response
    if ($response->UpdateSubscriptionsResult === '000') {
        // Update the database to reflect the subscription cancellation
        $wpdb->update(
            "{$wpdb->prefix}donor_gate_donations",
            ['status' => 'completed'],
            ['p2' => $reference],
            ['%s'],
            ['%s']
        );

        $response_message = 'The subscription has been reactivated successfully. Click Back to get redirected to donations.';
        $response_class = 'success';
    } else {
        // Include Netcash error responses
        $error_messages = [
            '100' => 'Authentication failed. Ensure the service key is correct.',
            '200' => 'Web service error. Contact support@netcash.co.za.',
            '311' => 'Merchant reference not found. Ensure the value in P2 refers to an existing subscription.',
            '313' => 'Invalid frequency. Ensure M18 contains one of the permitted values.',
            '314' => 'Invalid number of cycles. M17 must be greater than 0.',
            '315' => 'Invalid subscription start date. Format must be CCYYMMDD.',
        ];

        $error_code = $response->UpdateSubscriptionsResult;
        $response_message = $error_messages[$error_code] ?? 'Unknown error occurred.';
        $response_class = 'error';
    }
} catch (SoapFault $e) {
    error_log('SOAP Error: ' . $e->getMessage());
    $response_message = 'SOAP Error: ' . esc_html($e->getMessage());
    $response_class = 'error';
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
	
	<link rel="icon" href="https://netcash.co.za/wp-content/uploads/2024/11/donation_icon.svg" type="image/svg+xml">
    <title>Netcash Donations - Subscription</title>
    <style>
        body {
            background: radial-gradient(circle, #05b0a8, #7fd3d1);
            color: #333;
            font-family: 'Arial', serif;
            text-align: center;
            line-height: 1.6;
            margin: 0;
            padding: 0;
            display: flex;
            align-items: center;
            justify-content: center;
            min-height: 100vh;
        }

        #pay-invoice {
            max-width: 600px;
            margin: auto;
            padding: 20px;
            border-radius: 10px;
            
            color: #4d4a5b;
            font-family: 'Arial', serif;
			
        }

        .btn {
            background-color: white;
            color: #4d4a5b;
            border: none;
            padding: 12px 20px;
            border-radius: 5px;
            text-decoration: none;
            font-weight: bold;
            transition: background-color 0.3s;
        }

        .btn:hover {
            background-color: #e6e6e6;
        }

        footer {
            margin-top: 20px;
            font-size: 0.9rem;
            color: #666;
        }
.hidden {
    display: none;
}

#party-popper {
    position: fixed;
    top: 30%;
    left: 50%;
    transform: translateX(-50%);
    z-index: 9999;
}




    </style>
</head>
<body>
    <div id="pay-invoice">
        <div class="card-body">
            <div class="card-title">
			
				<img src="https://netcash.co.za/wp-content/uploads/2024/11/donation_icon.svg" style="width: 20%">
                <h2 style="color: #fff; margin-bottom: 15px;">Subscription reactivated successfully</h2>
				 <hr style="border-top: 1px solid #ddd;">
                <p style="font-size: 1.1rem; color: #fff;">
                  <?php echo esc_html($response_message); ?>
                </p>
            </div>
           <br>
    </div>
    <a href="<?php echo esc_url(admin_url('admin.php?page=donor-gate')); ?>"
        class="btn">
        Go Back
    </a>
        </div>

    <footer>
   
    </footer>
</body>
</html>
