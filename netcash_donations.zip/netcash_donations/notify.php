<?php
// Include WordPress environment
require_once($_SERVER['DOCUMENT_ROOT'] . '/wp-load.php');

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Capture POST data
    $transactionAccepted = $_POST['TransactionAccepted'] ?? null;
    $reference = $_POST['Reference'] ?? null;
    $amount = $_POST['Amount'] ?? null;
    $recurringFlag = $_POST['RecurringFlag'] ?? null;

    global $wpdb;
    $table_name = $wpdb->prefix . 'donor_gate_donations';

    if (is_null($transactionAccepted) || is_null($reference)) {
        die('Missing required POST data.');
    }

    // Fetch donor details from database
    $donation = $wpdb->get_row($wpdb->prepare("SELECT * FROM $table_name WHERE p2 = %s", $reference));

    if (!$donation) {
        die('Donation not found.');
    }

    $donor_name = $donation->name;
    $donor_surname = $donation->surname;
    $to_email = $donation->email_address;

    // Define transaction status
    $status = ($transactionAccepted === 'true') ? 'completed' : 'failed';

    // Process recurring and non-recurring donations
    if ($recurringFlag === 'true') {
        $wpdb->insert($table_name, [
            'p2' => $reference,
            'amount' => $amount,
            'status' => $status,
            'transaction_date' => current_time('mysql', 1),
            'name' => $donor_name,
            'surname' => $donor_surname
        ]);
    } else {
        $wpdb->update($table_name, ['status' => $status], ['p2' => $reference]);
    }

    if ($status === 'completed') {
        send_thank_you_email($to_email, $amount, $donor_name, $donor_surname);
    }

    echo 'Transaction processed successfully';
} else {
    header("HTTP/1.1 405 Method Not Allowed");
    echo "Request method not allowed.";
}

// Function to send email
function send_thank_you_email($to_email, $amount, $donor_name, $donor_surname) {
    $from_email = get_option('donor_gate_email_from', get_bloginfo('admin_email'));
    $custom_message = get_option('donor_gate_email_message', '');

    // Get the site logo dynamically
    $custom_logo_id = get_theme_mod('custom_logo');
    $logo_url = $custom_logo_id ? wp_get_attachment_image_src($custom_logo_id, 'full')[0] : '';
    $image_url = $logo_url ?: get_site_icon_url();

    // Fallback logo if no custom logo or site icon is set
    if (empty($image_url)) {
        $image_url = site_url('/wp-content/uploads/default-logo.png');
    }

    // Use placeholder if no custom message is set
    if (empty($custom_message)) {
        $custom_message = "Dear {name} {surname},<br>Thank you for your generous donation of R{amount}. Your support is greatly appreciated.<br>Best regards,<br>Netcash Donations";
    }

    // Replace placeholders with actual values
    $custom_message = str_replace(['{name}', '{surname}', '{amount}'], [$donor_name, $donor_surname, $amount], $custom_message);

    // Email content with logo
    $message = "
        <html>
        <head>
        <style>
            body { font-family: Arial, sans-serif; margin: 0; padding: 0; }
            .email-container { 
                max-width: 600px; 
                margin: 0 auto; 
                padding: 20px; 
                text-align: left; /* Ensures content aligns left */
            }
            .email-header { text-align: left; } /* Centers only the logo */
            .email-header img { max-width: 150px; margin-bottom: 20px; }
        </style>
    </head>
    <body>
        <div class='email-container'>
            <div class='email-header'>
                <img src='$image_url' alt='Donation Logo'>
            </div>
            <div class='email-body'>
                $custom_message
            </div>
        </div>
    </body>
        </html>
    ";
    $donor_gate_organisation_name = get_option('donor_gate_organisation_name', 'Your Organization');
    $headers = [
        'Content-Type: text/html; charset=UTF-8',
        'From: ' . esc_html($donor_gate_organisation_name) . ' <' . $from_email . '>'
    ];

    wp_mail($to_email, 'Donation Confirmation', $message, $headers);
}
?>
