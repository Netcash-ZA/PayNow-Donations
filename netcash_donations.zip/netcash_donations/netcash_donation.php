<?php
/*
Plugin Name: Netcash Donations
Plugin URI: https://github.com/Netcash-ZA/PayNow-Donations
Description: Netcash Donations is a comprehensive donation management plugin that allows organizations to securely accept one-time and recurring donations through Netcash.
Version: 4.0.2
Author: Netcash
Author URI: http://www.netcash.co.za/
*/

// Enqueue styles for the front-end
function donor_gate_enqueue_styles() {
    wp_enqueue_style('donor-gate-style', plugins_url('style.css', __FILE__));
}
add_action('wp_enqueue_scripts', 'donor_gate_enqueue_styles');

// Enqueue styles for the admin area
function donor_gate_admin_enqueue_styles() {
    wp_enqueue_style('donor-gate-admin-style', plugins_url('style.css', __FILE__));
}
add_action('admin_enqueue_scripts', 'donor_gate_admin_enqueue_styles');

// Add admin submenu for Netcash Donations, Welcome, and Settings
function donor_gate_add_admin_menu() {
    // Add main menu for Netcash with Welcome page as the default submenu
    add_menu_page(
    'Netcash Donations',                     // Page title
    'Netcash',                               // Menu title
    'manage_options',                        // Capability
    'donor-gate-welcome',                    // Menu slug for the welcome page
    'donor_gate_welcome_page',               // Function to display Welcome page
    'https://netcash.co.za/wp-content/uploads/2024/11/donation_icon.svg', // Custom icon URL
    5                                        // Position in the menu
);

// Custom CSS to style the Netcash menu icon
function donor_gate_custom_icon_css() {
    echo '
    <style>
        #adminmenu .menu-top.toplevel_page_donor-gate-welcome img {
            width: 18px;
            height: 18px;
            margin-top: -2px; /* Adjust the top margin to align vertically */
        }
    </style>';
}
add_action('admin_head', 'donor_gate_custom_icon_css');


    // Add Donations submenu under Netcash
    add_submenu_page(
        'donor-gate-welcome',                    // Parent slug
        'Donations',                             // Page title
        'Donations',                             // Submenu title
        'manage_options',                        // Capability
        'donor-gate',                            // Menu slug for Donations
        'donor_gate_admin_page'                  // Function to display Donations page
    );

    // Add Settings submenu under Netcash
    add_submenu_page(
        'donor-gate-welcome',                    // Parent slug
        'Settings',                              // Page title
        'Settings',                              // Submenu title
        'manage_options',                        // Capability
        'donor-gate-settings',                   // Menu slug for Settings
        'donor_gate_settings_page'               // Function to display Settings page
    );
}
add_action('admin_menu', 'donor_gate_add_admin_menu');

// Function to display the Welcome page
function donor_gate_welcome_page() {
    ?>
    <div class="wrap" style="max-width: 800px; margin: auto; font-family: Arial, background-color: #fff; sans-serif;">
				<!-- Include Font Awesome in the head of your HTML -->
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">

<div style="display: flex; justify-content: space-between; flex-wrap: wrap; margin: 20px 0;">
   <a href="<?php echo admin_url('admin.php?page=donor-gate'); ?>" style="flex: 1; min-width: 150px; padding: 15px 20px; background-color: #0000FF; color: white; text-decoration: none; border-radius: 5px; margin-right: 10px; text-align: center; font-size: 1.2rem; display: flex; align-items: center; justify-content: center;">
    <img src="https://netcash.co.za/wp-content/uploads/2024/11/donation_icon.svg" style="margin-right: 8px; width: 20px; height: 20px; display: inline-block; vertical-align: middle;">
    Donations
</a>
    <a href="<?php echo admin_url('admin.php?page=donor-gate-settings'); ?>" style="flex: 1; min-width: 150px; padding: 15px 20px; background-color: #0000FF; color: white; text-decoration: none; border-radius: 5px; margin-right: 10px; text-align: center; font-size: 1.2rem;">
        <i class="fas fa-gear" style="margin-right: 5px;"></i> Settings
    </a>
    
    <a href="mailto:support@netcash.co.za" style="flex: 1; min-width: 150px; padding: 15px 20px; background-color: #0000FF; color: white; text-decoration: none; border-radius: 5px; text-align: center; font-size: 1.2rem;">
         support@netcash.co.za
    </a>
</div>
        <h1 style="font-size: 2rem; color: #4d4a5b; text-align: left; font-weight: bold;">Welcome to Netcash Donations</h1>


        <p style="font-size: 1rem; color: #555; margin-top: 20px;">
            Thank you for using the Netcash Donations plugin. This tool enables you to easily manage and track donations through the Netcash payment gateway. Below is a tutorial on setting up and using the plugin.
        </p>

        <!-- YouTube Video Embed -->
        <div style="margin-top: 30px; text-align: center;">
            <iframe width="100%" height="400" src="https://www.youtube.com/embed/2bNfITIN9gg?si=gt4b3YTREBTxnDLm" 
                title="Netcash Donations Setup" frameborder="0" allowfullscreen></iframe>
        </div>

        
        <div style="margin-top: 40px;">
            <h2 style="font-size: 1.5rem; color: #333;">Thank you!</h2>
            <p style="font-size: 1rem; color: #555;">
                Enjoy your time with Netcash Donations.
            </p>
          <!-- Include Font Awesome in the head of your HTML -->
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">

<div style="display: flex; justify-content: space-between; flex-wrap: wrap; margin: 20px 0;">
    <a href="https://github.com/netcash-za" style="flex: 1; min-width: 150px; padding: 15px 20px; background-color: #0000FF; color: white; text-decoration: none; border-radius: 5px; margin-right: 10px; text-align: center; font-size: 1.2rem;">
        <i class="fas fa-book" style="margin-right: 5px;"></i> Read Full Guide
    </a>
    <a href="https://netcash.co.za/services/payment-gateway/" style="flex: 1; min-width: 150px; padding: 15px 20px; background-color: #0000FF; color: white; text-decoration: none; border-radius: 5px; margin-right: 10px; text-align: center; font-size: 1.2rem;">
        <i class="fas fa-link" style="margin-right: 5px;"></i> Visit Netcash
    </a>
    
   
</div>

        </div>
    </div>
    <?php
}

// Custom CSS for resizing the Netcash icon
function donor_gate_admin_css() {
    echo '
    <style>
        #adminmenu .menu-top.toplevel_page_donor-gate-welcome img {
            width: 16px;
            height: 16px;
            margin-top: 6px;
        }
    </style>';
}
add_action('admin_head', 'donor_gate_admin_css');




// Register the transaction details page
add_action('admin_menu', 'donorgate_register_transaction_details_page');

function donorgate_register_transaction_details_page() {
    add_submenu_page(
        'donor_gate_transactions', // Parent menu slug
        'Transaction Details',      // Page title
        'Transaction Details',      // Menu title
        'manage_options',           // Capability required
        'view_donorgate_transaction', // Menu slug
        'donorgate_render_transaction_details_page' // Callback function
    );
}

// Render the transaction details page content
function donorgate_render_transaction_details_page() {
    if (isset($_GET['reference'])) {
        $reference = sanitize_text_field($_GET['reference']);
        
        global $wpdb;
        $table_name = $wpdb->prefix . 'donor_gate_donations';

        // Fetch transaction details
        $transaction = $wpdb->get_row(
            $wpdb->prepare("SELECT * FROM {$table_name} WHERE p2 = %s", $reference)
        );

        if ($transaction) {
            ?>
            <div class="wrap">
                <h1 class="wp-heading-inline">Donation #<?php echo esc_html($transaction->p2); ?></h1>
                <a href="<?php echo admin_url('admin.php?page=donor-gate'); ?>" class="page-title-action">Back to Donations</a>

                <!-- Action buttons -->
                <div class="donor-gate-actions mt-3">
    <a href="<?php echo wp_nonce_url(admin_url('admin.php?page=view_donorgate_transaction&action=delete&reference=' . urlencode($transaction->p2)), 'donor_gate_delete_' . $transaction->p2); ?>" 
       class="btn btn-danger mr-2" 
       onclick="return confirm('Are you sure you want to delete this transaction?');">DELETE DONATION</a>

    <a href="<?php echo wp_nonce_url(admin_url('admin.php?page=view_donorgate_transaction&action=change_status&reference=' . urlencode($transaction->p2)), 'donor_gate_change_status_' . $transaction->p2); ?>" 
       class="btn btn-secondary mr-2">CHANGE STATUS</a>

    <a href="<?php echo plugin_dir_url(__FILE__) . 'transaction-details.php?action=download_certificate&reference=' . urlencode($transaction->p2); ?>" 
       class="btn btn-secondary">DONATION CERTIFICATE</a>
</div>

<style>
    /* Custom styling for the buttons */
    .donor-gate-actions .btn {
        font-size: 1rem; /* Larger, clear font size */
        font-weight: 500;
        padding: 10px 20px; /* Spacious padding for better touch targets */
        border-radius: 5px; /* Rounded corners for a modern look */
    }

    /* Danger button (Delete) styling */
    .donor-gate-actions .btn-danger {
        background-color: #F0F8FF;
        border: 1px solid;;
		border-color: #0073AA;
        color: #0073AA;
    }

    /* Secondary button styling */
    .donor-gate-actions .btn-secondary {
        background-color: #F0F8FF;
        border: 1px solid;
		border-color: #0073AA;
        color: #0073AA;
    }

    /* Hover effects for a subtle interaction */
    .donor-gate-actions .btn:hover {
        opacity: 0.9; /* Slight transparency for a hover effect */
        transform: scale(1.02); /* Slight scale-up effect */
    }

    /* Margin adjustment for better spacing */
    .donor-gate-actions .btn + .btn {
        margin-left: 10px; /* Consistent spacing between buttons */
    }
</style>
				<br>

                <!-- Include Bootstrap CSS if not already -->
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">

<section class="woocommerce-order-details">
    <h2 class="mb-4">Donation Details</h2>
    <table class="table table-bordered datatable" id="donationsTable">
        <tbody>
            <tr><th>Reference</th><td><?php echo esc_html($transaction->p2); ?></td></tr>
            <tr><th>Name</th><td><?php echo esc_html($transaction->name); ?></td></tr>
            <tr><th>Surname</th><td><?php echo esc_html($transaction->surname); ?></td></tr>
            <tr><th>Mobile Number</th><td><?php echo esc_html($transaction->mobile_number); ?></td></tr>
            <tr><th>Email Address</th><td><?php echo esc_html($transaction->email_address); ?></td></tr>
            <tr><th>Amount</th><td>R<?php echo esc_html($transaction->amount); ?></td></tr>
            <tr>
                <th>Status</th>
                <td><span style="color:<?php echo ($transaction->status === 'completed') ? 'green' : (($transaction->status === 'failed') ? 'red' : 'orange'); ?>;">
                    <?php echo ucfirst(esc_html($transaction->status)); ?>
                </span></td>
            </tr>
            <tr><th>Donation Type</th><td><?php echo esc_html($transaction->donation_type === 'recurring' ? 'Recurring' : 'Once-off'); ?></td></tr>
        </tbody>
    </table>
</section>

<style>
    /* General table styling */
    #donationsTable {
        font-size: 1rem; /* Slightly smaller font */
    }

    /* Header styling */
    #donationsTable th {
        width: 30%;
        font-weight: 600;
        color: #495057; /* Neutral dark gray for headings */
        background-color: #f1f1f1; /* Light gray background for headers */
        border-top: 1px solid #dee2e6;
    }

    /* Data cell styling */
    #donationsTable td {
        width: 70%;
        color: #343a40; /* Darker neutral text color */
    }

    /* Hover effect for rows */
    .table-bordered tbody tr:hover td {
        background-color: #f9f9f9; /* Light hover effect */
    }

    /* Section styling */
    .woocommerce-order-details {
        padding: 20px;
        background-color: #ffffff;
        border: 1px solid #e3e6ea;
        border-radius: 6px;
        box-shadow: 0 2px 8px rgba(0, 0, 0, 0.05); /* Softer shadow */
    }

    /* Adjust heading */
    .woocommerce-order-details h2 {
        font-size: 1.3rem;
        font-weight: 600;
        color: #343a40; /* Neutral dark color for heading */
    }
</style>

            </div>
            
            <?php

            // Handle delete and change status actions
            if (isset($_GET['action']) && $_GET['action'] === 'delete' && wp_verify_nonce($_GET['_wpnonce'], 'donor_gate_delete_' . $transaction->p2)) {
                $wpdb->delete($table_name, ['p2' => $reference]);
                echo "<p>Transaction deleted successfully.</p>";
            } elseif (isset($_GET['action']) && $_GET['action'] === 'change_status' && wp_verify_nonce($_GET['_wpnonce'], 'donor_gate_change_status_' . $transaction->p2)) {
                // Toggle status between 'completed' and 'failed'
                $new_status = ($transaction->status === 'completed') ? 'failed' : 'completed';
                $wpdb->update($table_name, ['status' => $new_status], ['p2' => $reference]);
                
                // Refresh page to show updated status
                echo "<script>window.location.href='" . admin_url('admin.php?page=view_donorgate_transaction&reference=' . urlencode($reference)) . "';</script>";
            }
        } else {
            echo "<p>No transaction details found for this reference.</p>";
        }
    } else {
        echo "<p>Invalid reference number.</p>";
    }
}



// Register settings
function donor_gate_register_settings() {
    register_setting('donor_gate_settings_group', 'donor_gate_m1_key');
    register_setting('donor_gate_settings_group', 'donor_gate_display_name');
    register_setting('donor_gate_settings_group', 'donor_gate_display_surname');
    register_setting('donor_gate_settings_group', 'donor_gate_display_email');
    register_setting('donor_gate_settings_group', 'donor_gate_display_mobile');
	register_setting('donor_gate_settings_group', 'donor_gate_button_color');
    register_setting('donor_gate_settings_group', 'donor_gate_toggle_color');
    register_setting('donor_gate_settings_group', 'donor_gate_amount_color');
	register_setting('donor_gate_settings_group', 'donor_gate_amount_1');
    register_setting('donor_gate_settings_group', 'donor_gate_amount_2');
    register_setting('donor_gate_settings_group', 'donor_gate_amount_3');
    register_setting('donor_gate_settings_group', 'donor_gate_amount_4');
    register_setting('donor_gate_settings_group', 'donor_gate_amount_5');
}
add_action('admin_init', 'donor_gate_register_settings');

// Add View Link in Transactions Table
function donor_gate_add_view_link_column($columns) {
    $columns['view_transaction'] = __('View', 'donor-gate');
    return $columns;
}
add_filter('manage_donor-gate_posts_columns', 'donor_gate_add_view_link_column');

function donor_gate_display_view_link_column($column, $post_id) {
    if ($column == 'view_transaction') {
        $view_url = plugin_dir_url(__FILE__) . 'view_transaction.php?transaction_id=' . $post_id;
        echo '<a href="' . esc_url($view_url) . '" target="_blank">View</a>';
    }
}
add_action('manage_donor-gate_posts_custom_column', 'donor_gate_display_view_link_column', 10, 2);


// Generate postback URLs dynamically (always regenerates to reflect folder changes)
function donor_gate_generate_postback_urls() {
    $plugin_dir = basename(plugin_dir_path(__FILE__)); // Get the actual plugin folder name
    $base_url = home_url('/'); // Get the domain where WordPress is installed

    // Build the URLs dynamically based on the plugin directory
    $accept_url = $base_url . 'wp-content/plugins/' . $plugin_dir . '/accept.php';
    $decline_url = $base_url . 'wp-content/plugins/' . $plugin_dir . '/decline.php';
    $notify_url = $base_url . 'wp-content/plugins/' . $plugin_dir . '/notify.php';

    // Update the URLs in the options table
    update_option('donor_gate_accept_url', $accept_url);
    update_option('donor_gate_decline_url', $decline_url);
    update_option('donor_gate_notify_url', $notify_url);
}

// Display postback URLs in settings page
function donor_gate_display_postback_urls() {
	$base_url = get_site_url(); // Get base URL for "Redirect URL"
    $accept_url = get_option('donor_gate_accept_url', '');
    $decline_url = get_option('donor_gate_decline_url', '');
    $notify_url = get_option('donor_gate_notify_url', '');

    echo '<h2>Netcash Netconnector Postback URLs</h2>';
	echo '<p>Log in to the <strong>Netcash Merchant portal</strong>, then navigate to Account Profile > <strong>NetConnector</strong> > Pay Now > Edit, and update the URLs below.<p><br>';
    echo '<p><strong>Accept URL:</strong> ' . esc_html($accept_url) . '</p>';
    echo '<p><strong>Decline URL:</strong> ' . esc_html($decline_url) . '</p>';
    echo '<p><strong>Notify URL:</strong> ' . esc_html($notify_url) . '</p>';
    echo '<p><strong>Redirect URL:</strong> ' . esc_html($base_url) . '</p>';
}

// Settings page content
function donor_gate_settings_page() {
    ?>
   <div class="wrap">
    <h1>Netcash Donations Settings</h1><br>

    <?php donor_gate_display_postback_urls(); ?>
	   <br>
	 <h2>Shortcode</h2>
	 <p>
		Copy the shortcode below and insert it into a page using the shortcode widget or HTML widget to display the donation form.
	   </p>  
    <h4>[netcash_form]</h4>
    <form method="post" action="options.php">
        <?php settings_fields('donor_gate_settings_group'); ?>
        <?php do_settings_sections('donor_gate_settings_group'); ?><br>
        
        <!-- Modern form table -->
        <h2>Form Settings</h2>         
        <table class="form-table modern-form-table">
            <tr valign="top">
                <th scope="row">Pay Now Service Key</th>
                <td><input type="text" name="donor_gate_m1_key" value="<?php echo esc_attr(get_option('donor_gate_m1_key', '')); ?>" class="styled-input" placeholder="Enter your service key" /></td>
            </tr>
            <tr valign="top">
                <th scope="row">Display Name</th>
                <td><input type="checkbox" name="donor_gate_display_name" value="1" <?php checked(get_option('donor_gate_display_name', '1'), '1'); ?> class="styled-checkbox" /></td>
            </tr>
            <tr valign="top">
                <th scope="row">Display Surname</th>
                <td><input type="checkbox" name="donor_gate_display_surname" value="1" <?php checked(get_option('donor_gate_display_surname', '1'), '1'); ?> class="styled-checkbox" /></td>
            </tr>
            <tr valign="top">
                <th scope="row">Display Email</th>
                <td><input type="checkbox" name="donor_gate_display_email" value="1" <?php checked(get_option('donor_gate_display_email', '1'), '1'); ?> class="styled-checkbox" /></td>
            </tr>
            <tr valign="top">
                <th scope="row">Display Mobile</th>
                <td><input type="checkbox" name="donor_gate_display_mobile" value="1" <?php checked(get_option('donor_gate_display_mobile', '1'), '1'); ?> class="styled-checkbox" /></td>
            </tr>

            <!-- New Color Fields -->
            <tr valign="top">
                <th scope="row">Submit Button Background Color</th>
                <td><input type="color" name="donor_gate_button_color" value="<?php echo esc_attr(get_option('donor_gate_button_color', '#0073aa')); ?>" /></td>
            </tr>
            <tr valign="top">
                <th scope="row">Toggle Menu Background Color</th>
                <td><input type="color" name="donor_gate_toggle_color" value="<?php echo esc_attr(get_option('donor_gate_toggle_color', '#0073aa')); ?>" /></td>
            </tr>
            <tr valign="top">
                <th scope="row">Amount Background Color</th>
                <td><input type="color" name="donor_gate_amount_color" value="<?php echo esc_attr(get_option('donor_gate_amount_color', '#0073aa')); ?>" /></td>
            </tr>
			<tr valign="top">
        <th scope="row">Custom Amount 1</th>
        <td><input type="number" name="donor_gate_amount_1" value="<?php echo esc_attr(get_option('donor_gate_amount_1', '50')); ?>" class="styled-input" placeholder="Enter amount 1" /></td>
    </tr>
    <tr valign="top">
        <th scope="row">Custom Amount 2</th>
        <td><input type="number" name="donor_gate_amount_2" value="<?php echo esc_attr(get_option('donor_gate_amount_2', '100')); ?>" class="styled-input" placeholder="Enter amount 2" /></td>
    </tr>
    <tr valign="top">
        <th scope="row">Custom Amount 3</th>
        <td><input type="number" name="donor_gate_amount_3" value="<?php echo esc_attr(get_option('donor_gate_amount_3', '250')); ?>" class="styled-input" placeholder="Enter amount 3" /></td>
    </tr>
    <tr valign="top">
        <th scope="row">Custom Amount 4</th>
        <td><input type="number" name="donor_gate_amount_4" value="<?php echo esc_attr(get_option('donor_gate_amount_4', '500')); ?>" class="styled-input" placeholder="Enter amount 4" /></td>
    </tr>
    <tr valign="top">
        <th scope="row">Custom Amount 5</th>
        <td><input type="number" name="donor_gate_amount_5" value="<?php echo esc_attr(get_option('donor_gate_amount_5', '1000')); ?>" class="styled-input" placeholder="Enter amount 5" /></td>
    </tr>
        </table>

        <?php submit_button(); ?>

        <!-- Add modern CSS styles for the form table -->
        <style>
            .modern-form-table {
                width: 100%;
                max-width: 700px;
                border-collapse: collapse;
                margin-bottom: 20px;
                background-color: #fff;
            }
            .modern-form-table th {
                text-align: left;
                padding: 15px;
                font-size: 16px;
                color: #333;
                border-bottom: 2px solid #eaeaea;
            }
            .modern-form-table td {
                padding: 15px;
                border-bottom: 1px solid #eaeaea;
            }
            .styled-input {
                width: 100%;
                max-width: 600px;
                padding: 10px;
                font-size: 16px;
                border: 2px solid #ccc;
                border-radius: 5px;
                transition: border-color 0.3s ease, box-shadow 0.3s ease;
            }
            .styled-input:hover,
            .styled-input:focus {
                border-color: #0073aa;
                box-shadow: 0 0 8px rgba(0, 115, 170, 0.2);
                outline: none;
            }
            .styled-checkbox {
                width: 20px;
                height: 20px;
                border-radius: 3px;
                transition: 0.3s ease;
                vertical-align: middle;
            }
            .modern-form-table tr:hover {
                background-color: #f9f9f9;
            }
            .form-table {
                margin-top: 20px;
            }
        </style>
    </form>
</div>

    <?php
}

// Display donations in the admin panel
function donor_gate_admin_page() {
    global $wpdb;
    $table_name = $wpdb->prefix . 'donor_gate_donations';
    $donations = $wpdb->get_results("SELECT * FROM $table_name ORDER BY id DESC");

    if ($wpdb->last_error) {
        echo '<div class="error"><p>Error fetching donation records: ' . esc_html($wpdb->last_error) . '</p></div>';
        return;
    }
    ?>
<?php
// Get the base URL of your site
$base_url = get_site_url();
?>
    <div class="wrap">
		
<!-- Bootstrap CSS -->
<link href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" rel="stylesheet">
<!-- DataTables CSS -->
<link rel="stylesheet" href="https://cdn.datatables.net/1.11.5/css/jquery.dataTables.min.css">

<style>
    /* Custom styles for the table */
    #donationsTable {
        width: 100%; /* Use viewport width to fill the whole page */
        margin: 0; /* Remove default margins */
    }

    /* Remove vertical borders */
    #donationsTable td, #donationsTable th {
        border-left: none;
        border-right: none;
    }

    /* Add horizontal borders */
    #donationsTable tr {
        border-bottom: 1px solid #dee2e6; /* Horizontal line color */
    }

    /* Change the hover effect */
    #donationsTable tbody tr:hover {
        background-color: #f5f5f5; /* Light gray on hover */
    }

    /* Style for status labels */
    .status-label {
        padding: 5px 10px;
        border-radius: 5px;
        color: white;
    }
</style>

<div class="container-fluid mt-4">
    
    <?php
    // Initialize counters
    $total_donated = 0;
    $total_failed = 0;
    $total_pending = 0;

    // Calculate totals
    if ($donations) {
        foreach ($donations as $donation) {
            if ($donation->status === 'completed') {
                $total_donated += $donation->amount;
            } elseif ($donation->status === 'failed') {
                $total_failed++;
            } elseif ($donation->status === 'pending') {
                $total_pending++;
            }
        }
    }
    ?>

    <!-- Include Font Awesome in the head of your HTML -->
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">

<!-- Donation Stats Summary -->
<div class="stats-summary d-flex justify-content-center gap-3 mb-4">
    <div class="stat-box total-donated" style="border: 1px solid #4CAF50; border-radius: 8px; padding: 20px; display: flex; align-items: center; background-color: #DFF2E1;">
        <i class="fas fa-money-bill-wave" style="font-size: 2rem; color: #4CAF50; margin-right: 15px;"></i>
        <div style="flex-grow: 1; text-align: center;">
            <h4 style="margin: 0; color: #333;">Amount Donated</h4>
            <div class="stat-amount" style="font-size: 1.5rem; font-weight: bold; color: #4CAF50;">R<?php echo number_format($total_donated, 2); ?></div>
        </div>
    </div>
    
    <div class="stat-box total-failed" style="border: 1px solid #dc3545; border-radius: 8px; padding: 20px; display: flex; align-items: center; background-color: #f8d7da;">
        <i class="fas fa-times-circle" style="font-size: 2rem; color: #dc3545; margin-right: 15px;"></i>
        <div style="flex-grow: 1; text-align: center;">
            <h4 style="margin: 0; color: #333;">Total Failed</h4>
            <div class="stat-amount" style="font-size: 1.5rem; font-weight: bold; color: #dc3545;"><?php echo $total_failed; ?></div>
        </div>
    </div>
    
    <div class="stat-box total-pending" style="border: 1px solid #ffc107; border-radius: 8px; padding: 20px; display: flex; align-items: center; background-color: #fff3cd;">
        <i class="fas fa-hourglass-half" style="font-size: 2rem; color: #ffc107; margin-right: 15px;"></i>
        <div style="flex-grow: 1; text-align: center;">
            <h4 style="margin: 0; color: #333;">Total Pending</h4>
            <div class="stat-amount" style="font-size: 1.5rem; font-weight: bold; color: #ffc107;"><?php echo $total_pending; ?></div>
        </div>
    </div>
</div>


    <table class="table table-striped datatable" id="donationsTable">
    <thead class="thead-primary">
        <tr>
            <th scope="col">Timestamp</th>
            <th scope="col">Reference</th>
            <th scope="col">Name</th>
            <th scope="col">Surname</th>
            <th scope="col">Cellphone</th>
            <th scope="col">Email Address</th>
            <th scope="col">Amount</th>
            <th scope="col">Status</th>
            <th scope="col">Type</th>
            <th scope="col">Action</th> <!-- New Action Column -->
        </tr>
    </thead>
    <tbody>
    <?php if ($donations) : ?>
        <?php foreach ($donations as $donation) : ?>
            <tr>
                <td><?php echo esc_html($donation->created_at); ?></td>
                <td><?php echo esc_html($donation->p2); ?></td>
                <td><?php echo esc_html($donation->name); ?></td>
                <td><?php echo esc_html($donation->surname); ?></td>
                <td><?php echo esc_html($donation->mobile_number); ?></td>
                <td><?php echo esc_html($donation->email_address); ?></td>
                <td>R<?php echo esc_html($donation->amount); ?></td>
                <td>
                    <span class="status-label <?php echo esc_attr($donation->status); ?>">
    <?php echo ucfirst(esc_html($donation->status)); ?>
</span>

<style>
    /* General status label styling */
    .status-label {
        display: inline-block;
        padding: 5px 10px;
        font-weight: bold;
        border-radius: 4px;
        font-size: 0.9rem;
    }

    /* Completed status styling */
    .status-label.completed {
        background-color: #DFF2E1; /* Light green */
        color: #4CAF50; /* Strong green */
        border: 1px solid #4CAF50; /* Strong green */
    }

    /* Failed status styling */
    .status-label.failed {
        background-color: #FDDCDC; /* Light red */
        color: #F44336; /* Strong red */
        border: 1px solid #F44336; /* Strong red */
    }

    /* Pending status styling */
    .status-label.pending {
        background-color: #FFE5CC; /* Light orange */
        color: #FF9800; /* Strong orange */
        border: 1px solid #FF9800; /* Strong orange */
    }
</style>

                </td>
                <td><?php echo esc_html($donation->donation_type === 'recurring' ? 'Recurring' : 'Once-off'); ?></td>
                <td>
                    <!-- View Icon Link -->
                    <a href="<?php echo admin_url('admin.php?page=view_donorgate_transaction&reference=' . urlencode($donation->p2)); ?>">
    <i class="dashicons dashicons-visibility"></i>
</a>

                </td>
            </tr>
        <?php endforeach; ?>
    <?php else : ?>
        <tr>
            <td colspan="10" class="text-center">No donations found.</td>
        </tr>
    <?php endif; ?>
    </tbody>
</table>

</div>

<!-- Styling for Stats Summary -->
<style>
    .stats-summary {
        gap: 15px;
    }
    .stat-box {
        flex: 1;
        padding: 15px 20px;
        color: #fff;
        border-radius: 8px;
        box-shadow: 0 4px 10px rgba(0, 0, 0, 0.1);
        text-align: center;
    }

    /* Background colors for each stat box */
    .total-donated {
        background-color: #4CAF50;
    }
    .total-failed {
        background-color: #F44336;
    }
    .total-pending {
        background-color: #FF9800;
    }

    .stat-box h4 {
        margin: 0;
        font-weight: 600;
    }

    .stat-amount {
        font-size: 1.8rem;
        font-weight: bold;
        margin-top: 5px;
    }

    .table-striped tbody tr:hover {
        background-color: #f2f2f2;
    }

    .status-label {
        padding: 5px 10px;
        border-radius: 4px;
        color: #fff;
        font-weight: bold;
    }
</style>

<!-- Export Button -->
<div class="text-end mt-4">
    <form method="post">
        <button type="submit" name="export_csv" class="btn btn-secondary">Export to CSV</button>
    </form>
</div>

<?php
// CSV Export Functionality
if (isset($_POST['export_csv'])) {
    // Fetch only successful donations for export
    $csv_donations = $wpdb->get_results("SELECT created_at, p2, name, surname, mobile_number, email_address, amount, status, donation_type FROM {$wpdb->prefix}donor_gate_donations");

    // Prepare CSV data
    $filename = 'donations_export_' . date('Ymd') . '.csv';
    header('Content-Type: text/csv');
    header('Content-Disposition: attachment; filename="' . $filename . '"');

    $output = fopen('php://output', 'w');
    fputcsv($output, ['Timestamp', 'Reference', 'Name', 'Surname', 'Mobile Number', 'Email Address', 'Amount', 'Status', 'Type']); // CSV headers

    foreach ($csv_donations as $donation) {
        fputcsv($output, [
            $donation->created_at,
            $donation->p2,
            $donation->name,
            $donation->surname,
            $donation->mobile_number,
            $donation->email_address,
            'R' . $donation->amount,
            ucfirst($donation->status),
            ($donation->donation_type === 'recurring' ? 'Recurring' : 'Once-off')
        ]);
    }

    fclose($output);
    exit();
}
?>



<!-- jQuery -->
<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
<!-- DataTables JS -->
<script src="https://cdn.datatables.net/1.11.5/js/jquery.dataTables.min.js"></script>

<!-- Initialize DataTables -->
<script>
    jQuery(document).ready(function($) {
        $('#donationsTable').DataTable({
            "paging": true,          // Enable pagination
            "searching": true,       // Enable search functionality
            "ordering": true,        // Enable column sorting
            "info": true,            // Show table info (number of entries)
            "pageLength": 10,        // Default number of rows per page
            "lengthChange": true,    // Allow the user to change page length
            "language": {
                "search": "Filter results:",  // Customize search label
                "lengthMenu": "Show _MENU_ entries",
                "info": "Showing _START_ to _END_ of _TOTAL_ entries"
            },
            "columnDefs": [
                { "orderable": false, "targets": [1] } // Disable ordering for the Reference column
            ],
            "order": [[0, "desc"]] // Set the default order to the first column (Timestamp) in descending order
        });
    });
</script>


    </div>
    <?php
}

// Activate plugin and create table (with donation type)
function donor_gate_activate() {
    global $wpdb;
    $table_name = $wpdb->prefix . 'donor_gate_donations';
    $charset_collate = $wpdb->get_charset_collate();

    $sql = "CREATE TABLE $table_name (
        id mediumint(9) NOT NULL AUTO_INCREMENT,
        name tinytext NOT NULL,
        surname tinytext NOT NULL,
        mobile_number varchar(15) NOT NULL,
        email_address varchar(100) NOT NULL,
        amount float NOT NULL,
        p2 tinytext NOT NULL,
        status varchar(20) DEFAULT 'pending',
        donation_type varchar(20) DEFAULT 'once_off', /* Added donation type column */
        created_at datetime DEFAULT CURRENT_TIMESTAMP NOT NULL,
        PRIMARY KEY (id)
    ) $charset_collate;";

    require_once(ABSPATH . 'wp-admin/includes/upgrade.php');
    dbDelta($sql);

    donor_gate_generate_postback_urls();
}
register_activation_hook(__FILE__, 'donor_gate_activate');

// Donation form shortcode
function donor_gate_form_shortcode() {
    ob_start();
    global $wpdb;
    $table_name = $wpdb->prefix . 'donor_gate_donations';

    $display_name = get_option('donor_gate_display_name', '1');
    $display_surname = get_option('donor_gate_display_surname', '1');
    $display_email = get_option('donor_gate_display_email', '1');
    $display_mobile = get_option('donor_gate_display_mobile', '1');

    if ($_SERVER['REQUEST_METHOD'] == 'POST') {
        if (!isset($_POST['donation_form_nonce']) || !wp_verify_nonce($_POST['donation_form_nonce'], 'donation_form_action')) {
            die('Security check failed!');
        }

        $name = ($display_name == '1') ? sanitize_text_field($_POST['m4']) : 'Anonymous';
        $surname = ($display_surname == '1') ? sanitize_text_field($_POST['m5']) : 'Anonymous';
        $email_address = ($display_email == '1') ? sanitize_email($_POST['m9']) : 'noreply@netcash.co.za';
        $mobile_number = ($display_mobile == '1') ? sanitize_text_field($_POST['m11']) : '0000000000';
        $amount = sanitize_text_field($_POST['p4']);
        $reference = uniqid();

        // Capture donation type (Once-off or Recurring)
        $donation_type = $_POST['donation_type'] ?? 'once_off'; // Default to once_off

        // Insert form data into the database
        $wpdb->insert(
            $table_name,
            [
                'name' => $name,
                'surname' => $surname,
                'mobile_number' => $mobile_number,
                'email_address' => $email_address,
                'amount' => $amount,
                'p2' => $reference,
                'status' => 'pending',
                'donation_type' => $donation_type, // Store the donation type
                'created_at' => current_time('mysql'),
            ]
        );

        $m1_key = get_option('donor_gate_m1_key', '');
        $recurring_fields = '';

        $current_date = new DateTime();
        $start_date = $current_date->modify('+1 month')->format('Y-m-d');

        if ($donation_type === 'recurring') {
            $recurring_fields = '
                <input type="text" hidden name="m16" value="1">
                <input type="text" hidden name="m14" value="1">
                <input type="text" hidden name="m17" value="999">
                <input type="text" hidden name="m18" value="1">
                <input type="date" hidden name="m19" value="' . $start_date . '">
                <input type="text" hidden id="m20" name="m20" value="' . $amount . '">
            ';
        }

        ?>
        <form id="redirect-form" method="POST" action="https://paynow.netcash.co.za/site/paynow.aspx" target="_top">
            <input type="hidden" id="m1" name="m1" value="<?php echo esc_attr($m1_key); ?>" required>
            <input type="hidden" id="m2" name="m2" value="24ade73c-98cf-47b3-99be-cc7b867b3080" required>
            <input type="hidden" name="p2" value="<?php echo $reference; ?>">
            <input type="hidden" name="p3" value="Donation by <?php echo $name . ' ' . $surname; ?>">
            <input type="hidden" name="p4" value="<?php echo $amount; ?>">
            <input type="hidden" name="m4" value="<?php echo $name; ?>">
            <input type="hidden" name="m5" value="<?php echo $surname; ?>">
            <input type="hidden" name="m9" value="<?php echo $email_address; ?>">
            <input type="hidden" name="m11" value="<?php echo $mobile_number; ?>">
            <?php echo $recurring_fields; ?>
        </form>
        <script type="text/javascript">
            document.getElementById('redirect-form').submit();
        </script>
        <?php
        exit;
    }

    ?>
<?php
// Retrieve color settings from the database
$button_color = esc_attr(get_option('donor_gate_button_color', '#0073aa'));  // Button color with default
$toggle_color = esc_attr(get_option('donor_gate_toggle_color', '#0073aa'));  // Toggle color with default
$amount_color = esc_attr(get_option('donor_gate_amount_color', '#0073aa'));  // Amount color with default
?>


<?php
// Fetch saved color options from the database
$button_color = esc_attr(get_option('donor_gate_button_color', '#007bff')); // Default: Blue
$toggle_color = esc_attr(get_option('donor_gate_toggle_color', '#007bff')); // Default: Blue
$amount_color = esc_attr(get_option('donor_gate_amount_color', '#f8f9fa')); // Default: Light gray
?>


<!-- Display Donation Form with Toggle Menu -->
<form name="donation-form" id="donation-form" method="POST">
    <?php wp_nonce_field('donation_form_action', 'donation_form_nonce'); ?>

    <!-- Toggle Menu for Once-off and Recurring Donations -->
    <div id="donation-tab" class="centered-toggle-menu">
        <button type="button" id="once-off-btn" class="toggle-btn active" onclick="setDonationType('once_off')">One-time</button>
        <button type="button" id="recurring-btn" class="toggle-btn" onclick="setDonationType('recurring')">Monthly</button>
    </div>

    <input type="hidden" id="donation_type" name="donation_type" value="once_off">

    <!-- Name Field (m4) -->
    <?php if ($display_name == '1') : ?>
    <div class="form-row">
        <label for="m4"><strong>Name</strong></label>
        <input type="text" class="form-control" id="m4" name="m4" placeholder="Enter your name">
    </div>
    <?php endif; ?>

    <!-- Surname Field (m5) -->
    <?php if ($display_surname == '1') : ?>
    <div class="form-row">
        <label for="m5"><strong>Surname</strong></label>
        <input type="text" class="form-control" id="m5" name="m5" placeholder="Enter your surname">
    </div>
    <?php endif; ?>

    <!-- Email Field (m9) -->
    <?php if ($display_email == '1') : ?>
    <div class="form-row">
        <label for="m9"><strong>Email Address</strong></label>
        <input type="email" class="form-control" id="m9" name="m9" placeholder="Enter your email address">
    </div>
    <?php endif; ?>

    <!-- Mobile Field (m11) -->
    <?php if ($display_mobile == '1') : ?>
    <div class="form-row">
        <label for="m11"><strong>Mobile Number</strong></label>
        <input type="tel" class="form-control" id="m11" name="m11" placeholder="Enter your mobile number">
    </div>
    <?php endif; ?>

    <input type="hidden" name="p2" id="p2" value="<?php echo uniqid(); ?>"> <!-- Unique Reference -->
    <input type="hidden" name="p3" id="p3" value="">

    <!-- Donation Amount Radio Buttons -->
    <div class="form-row amount-options">
        <label><strong>Choose Amount</strong></label>
        <div class="custom-radio-group">
            <?php 
            // Fetch customizable amounts from settings
            $amounts = [
                get_option('donor_gate_amount_1', 50),
                get_option('donor_gate_amount_2', 100),
                get_option('donor_gate_amount_3', 250),
                get_option('donor_gate_amount_4', 500),
                get_option('donor_gate_amount_5', 1000),
                'Custom'
            ];

            // Render radio buttons for each amount
            foreach ($amounts as $amount) : ?>
                <label class="custom-radio" style="background-color: <?php echo $amount_color; ?>;">
                    <input type="radio" required name="amount" value="<?php echo is_numeric($amount) ? $amount : 'Custom'; ?>" onclick="enableCustomAmount()">
                    <span><?php echo is_numeric($amount) ? 'R' . $amount : 'Custom'; ?></span>
                </label>
            <?php endforeach; ?>
        </div>
    </div>

    <!-- Custom Amount Field -->
    <div class="form-row">
        <label for="p4">Amount:</label>
        <input type="text" id="p4" name="p4" class="form-control" value="" readonly required>
    </div>

    <button type="submit" class="btn btn-primary mt-3" style="background-color: <?php echo $button_color; ?>; color: #fff;">
        Donate Now
    </button><br><br>
<!-- "Powered by Netcash" section with logo, centered and aligned -->
<div style="
    text-align: center;
    font-size:18px;
	
    align-items: center;
    justify-content: center;
">
    
    <a href="https://netcash.co.za" target="_blank" style="display: inline-flex; align-items: center;">
        <img src="https://paynow.netcash.co.za/Resources/Images/20240710/powered-by-netcash.png" alt="Netcash Logo" style="height: 50px; font-style: italic;">
    </a>
</div>
</form>

<!-- JavaScript for Toggle Functionality -->
<script>
    function setDonationType(type) {
        const toggleColor = "<?php echo $toggle_color; ?>";

        // Get the buttons
        const onceOffBtn = document.getElementById('once-off-btn');
        const recurringBtn = document.getElementById('recurring-btn');
        
        // Set active class and styles based on selected type
        if (type === 'once_off') {
            onceOffBtn.classList.add('active');
            onceOffBtn.style.backgroundColor = toggleColor;
            onceOffBtn.style.color = '#fff';

            recurringBtn.classList.remove('active');
            recurringBtn.style.backgroundColor = '#e0e0e0';
            recurringBtn.style.color = '#333';
        } else {
            recurringBtn.classList.add('active');
            recurringBtn.style.backgroundColor = toggleColor;
            recurringBtn.style.color = '#fff';

            onceOffBtn.classList.remove('active');
            onceOffBtn.style.backgroundColor = '#e0e0e0';
            onceOffBtn.style.color = '#333';
        }

        // Set the donation type in the hidden field
        document.getElementById('donation_type').value = type;
    }
</script>

<!-- Styling Section -->
<style>
    /* Main Form Styles */
    form {
        background-color: #fff;
        padding: 20px;
        border-radius: 8px;
        box-shadow: 0 2px 15px rgba(0, 0, 0, 0.1);
        max-width: 600px;
        margin: auto;
        font-family: Arial, sans-serif;
    }

    /* Centering the toggle menu */
    .centered-toggle-menu {
        display: flex;
        justify-content: space-between;
        margin-bottom: 20px;
    }

     /* Toggle Button styles */
    .toggle-btn {
        padding: 12px 24px;
        cursor: pointer;
        border: 1px solid #ccc;
        background-color: #f8f9fa;
        color: #333;
        margin: 0;
        font-size: 16px;
        border-radius: 5px;
        transition: background-color 0.3s ease, color 0.3s ease;
        width: 48%;
        text-align: center;
    }

    /* Active button */
    .toggle-btn.active {
        background-color: <?php echo $toggle_color; ?>;
        color: #fff;
    }

    /* Form Group */
    .form-row {
        margin-bottom: 15px;
    }

    /* Form Control styles */
    .form-control {
        width: 100%;
        padding: 10px;
        font-size: 16px;
        border: 1px solid #ddd;
        border-radius: 5px;
        box-shadow: none;
    }

    /* Custom radio buttons */
    .custom-radio-group {
        display: flex;
        flex-wrap: wrap;
        gap: 10px;
        justify-content: space-between;
    }

    .custom-radio {
        display: inline-block;
        cursor: pointer;
        border: 1px solid #ddd;
        border-radius: 5px;
        padding: 15px;
        text-align: center;
        width: calc(33% - 10px);
        font-size: 16px;
    }

    .custom-radio input[type="radio"] {
        display: none;
    }

    .custom-radio span {
        display: block;
    }

    /* Submit Button */
    .btn-primary {
        width: 100%;
        padding: 12px;
        font-size: 18px;
        background-color: <?php echo $button_color; ?>;
        color: #fff;
        border: none;
        border-radius: 5px;
        cursor: pointer;
        transition: background-color 0.3s ease;
    }

    .btn-primary:hover {
        background-color: #0056b3;
    }
</style>

<style>
    /* Centering the toggle menu */
    .centered-toggle-menu {
        display: flex;
        justify-content: center;
        margin-bottom: 20px;
        gap: 10px;
    }

    /* Toggle Button styles */
    .toggle-btn {
        padding: 12px 24px;
        cursor: pointer;
		text-transform: capitalize;
        border: 2px solid var(--wp--preset--color--primary, #007bff); /* Use theme primary color */
        background-color: <?php echo $toggle_color; ?>;
        color: var(--wp--preset--color--primary, #333331);
        margin: 0;
        font-size: 16px;
        border-radius: 8px;
        transition: background-color 0.3s ease, color 0.3s ease;
    }

    /* Active button */
    .toggle-btn.active {
        background-color: <?php echo $toggle_color; ?>;
        color: #fff;
    }

    /* Hover effect */
    .toggle-btn:hover {
        background-color: var(--wp--preset--color--primary, <?php echo $toggle_color; ?>);
        color: #fff;
    }

    /* Form Control styles */
    .form-control {
        width: 100%;
        padding: 12px;
        font-size: 16px;
        border: 1px solid #ccc;
        border-radius: 5px;
        transition: border-color 0.3s ease, box-shadow 0.3s ease;
    }

    .form-control:focus {
        border-color: var(--wp--preset--color--primary, #007bff);
        box-shadow: 0 0 8px rgba(0, 123, 255, 0.25);
    }

    /* Form Group */
    .form-group {
        margin-bottom: 20px;
    }

    /* Custom radio buttons */
    .custom-radio-group {
        display: flex;
        gap: 10px;
        flex-wrap: wrap;
    }

    .custom-radio {
        display: flex;
        align-items: center;
        cursor: pointer;
    }

    .custom-radio input[type="radio"] {
        margin-right: 8px;
    }
	
	.custom-radio input[type="radio"]:checked + span {
    background-color: <?php echo $toggle_color; ?>;
    color: white;
}
	

    /* Button styles */
    .btn-primary {
        width: 100%;
        font-size: 18px;
        padding: 12px;
        background-color: var(--wp--preset--color--primary, <?php echo $toggle_color; ?>);
        color: #fff;
		text-transform: capitalize;
        border: none;
        border-radius: 5px;
        transition: background-color 0.3s ease;
    }

    .btn-primary:hover {
        background-color: var(--wp--preset--color--primary, <?php echo $toggle_color; ?>);
    }
</style>




    <script>
    function enableCustomAmount() {
        const radios = document.getElementsByName('amount');
        let selectedValue = '';

        // Loop through each radio button to find the selected value
        for (const radio of radios) {
            if (radio.checked) {
                selectedValue = radio.value;
                break;
            }
        }

        const customAmountField = document.getElementById('p4');
        
        // Enable or disable the custom amount field based on selection
        if (selectedValue === '' || selectedValue === 'Custom' || selectedValue === 'OwnAmt') {
            customAmountField.value = ''; // Clear previous input
            customAmountField.readOnly = false; // Allow editing
            customAmountField.placeholder = 'Enter your own amount'; // Optional placeholder for guidance
        } else {
            customAmountField.value = selectedValue; // Set the amount to the selected value
            customAmountField.readOnly = true; // Make the field read-only
        }
    }

    function setDonationType(type) {
        document.getElementById('donation_type').value = type;
        document.getElementById('once-off-btn').classList.remove('active');
        document.getElementById('recurring-btn').classList.remove('active');
        
        // Toggle the active button style based on selection
        if (type === 'once_off') {
            document.getElementById('once-off-btn').classList.add('active');
        } else {
            document.getElementById('recurring-btn').classList.add('active');
        }
    }

    document.write(`
        <style>
            .toggle-btn { padding: 12px; cursor: pointer; background-color: #E2E2E8; border: none; }
            .toggle-btn.active { background-color: <?php echo $toggle_color; ?>; color: white; }
        </style>
    `);
</script>

    <?php
    return ob_get_clean();
}
add_shortcode('netcash_form', 'donor_gate_form_shortcode');
?>