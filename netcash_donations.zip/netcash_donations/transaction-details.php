<?php
/*
Template Name: Transaction Details
*/

// Include WordPress to access WP functions
require_once('../../../wp-load.php'); // Adjust the path if necessary

// Access global $wpdb
global $wpdb;
$table_name = $wpdb->prefix . 'donor_gate_donations';

// Get the reference from the URL
$reference = isset($_GET['reference']) ? sanitize_text_field($_GET['reference']) : '';

if (!empty($reference)) {
    // Query the transaction using the reference number
    $donation = $wpdb->get_row($wpdb->prepare("SELECT * FROM $table_name WHERE p2 = %s", $reference));

    if ($donation) {
        ?>
        <div id="certificate" style="
            width: 100%; max-width: 800px; margin: auto; padding: 50px;
             border-radius: 15px;
            background-image: url('https://netcash.co.za/wp-content/uploads/2024/11/Donation_background-100.jpg'); color: #333; font-family: 'Georgia', serif;
            text-align: center; line-height: 1.6;
        ">
            <h1 style="font-size: 2.5rem; color: #4d4a5b; margin-bottom: 0;">Certificate of Donation</h1>
            <p style="font-size: 1.2rem; color: #4d4a5b; font-style: italic;">Presented to</p>
            
            <div style="
                font-size: 1.6rem; font-weight: bold; color: #4d4a5b;
                margin: 15px 0 20px; text-transform: capitalize;
            ">
                <?php echo esc_html($donation->name . ' ' . $donation->surname); ?>
            </div>

            <p style="font-size: 1.2rem; color: #4d4a5b;">
                for a generous donation of <strong>R<?php echo esc_html($donation->amount); ?></strong>
            </p>

            <div style="
                margin: 20px 0; padding: 15px 30px;
                background-color: #f8f8f8; border-radius: 10px;
                box-shadow: 0 4px 10px rgba(0, 0, 0, 0.15);
                text-align: center;
            ">
                <p><strong>Reference Number:</strong> <?php echo esc_html($donation->p2); ?></p>
                <p><strong>Status:</strong> <?php echo ucfirst(esc_html($donation->status)); ?></p>
                <p><strong>Donation Type:</strong> <?php echo esc_html($donation->donation_type === 'recurring' ? 'Recurring' : 'Once-off'); ?></p>
                <p><strong>Date of Donation:</strong> <?php echo esc_html(date("F j, Y", strtotime($donation->created_at))); ?></p>
            </div>

            <p style="font-size: 1.2rem; color: #4d4a5b; margin-top: 25px;">
                Thank you for your invaluable support and contribution.
            </p>
            <p style="font-size: 1rem; color: #4d4a5b;">
                This certificate is issued as a token of appreciation for your generosity.
            </p>

            <div style="margin-top: 25px; font-size: 0.9rem; color: #4d4a5b;">
                Generated on <?php echo date("F j, Y"); ?> <br>
				By Netcash Donation
            </div>
        </div>

        <!-- Download Certificate and Back to Donations Buttons -->
        <div style="text-align: center; margin-top: 20px;">
            <button onclick="downloadCertificate()" style="
                background-color: #0000FF; color: white; padding: 12px 24px;
                border: none; border-radius: 5px; font-size: 1rem; cursor: pointer;
                transition: background-color 0.3s;
            ">
                Download Certificate
            </button>
            <button onclick="window.location.href='<?php echo admin_url('admin.php?page=donor-gate'); ?>'" style="
                background-color: #0000FF; color: white; padding: 12px 24px;
                border: none; border-radius: 5px; font-size: 1rem; cursor: pointer;
                margin-left: 10px; transition: background-color 0.3s;
            ">
                Back to Donations
            </button>
        </div>

        <!-- Include html2pdf.js from CDN -->
        <script src="https://cdnjs.cloudflare.com/ajax/libs/html2pdf.js/0.9.2/html2pdf.bundle.min.js"></script>
        <script>
            function downloadCertificate() {
                const element = document.getElementById('certificate');
                const options = {
                    margin:       0.2,  // Slight margin to ensure border visibility
                    filename:     'Donation_Certificate_<?php echo $reference; ?>.pdf',
                    image:        { type: 'jpeg', quality: 0.98 },
                    html2canvas:  { scale: 2 },
                    jsPDF:        { unit: 'in', format: 'a4', orientation: 'landscape' } // Set to landscape
                };
                html2pdf().set(options).from(element).save();
            }
        </script>
        <?php
    } else {
        echo "<p>No transaction found with the specified reference.</p>";
    }
} else {
    echo "<p>No reference specified.</p>";
}
?>
