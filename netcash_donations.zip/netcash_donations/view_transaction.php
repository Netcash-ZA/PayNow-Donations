<?php
// Load WordPress environment
require_once(dirname(__FILE__) . '/../../../wp-load.php'); // Adjust the path if necessary

global $wpdb;

if (isset($_GET['reference'])) {
    $reference = sanitize_text_field($_GET['reference']);

    // Define table name dynamically with prefix
    $table_name = $wpdb->prefix . 'donor_gate_donations';

    // Query to fetch transaction by `p2` (reference column)
    $transaction = $wpdb->get_row(
        $wpdb->prepare(
            "SELECT * FROM {$table_name} WHERE p2 = %s",
            $reference
        )
    );

    if ($transaction) {
        ?>
        <div class="woocommerce">
            <h1 class="woocommerce-order-title">Transaction #<?php echo esc_html($transaction->p2); ?></h1>
            
            <section class="woocommerce-order-details">
                <h2>Transaction Details</h2>
                <table class="woocommerce-table woocommerce-table--order-details shop_table order_details">
                    <tbody>
                        <tr>
                            <th>Reference</th>
                            <td><?php echo esc_html($transaction->p2); ?></td>
                        </tr>
                        <tr>
                            <th>Name</th>
                            <td><?php echo esc_html($transaction->name); ?></td>
                        </tr>
                        <tr>
                            <th>Surname</th>
                            <td><?php echo esc_html($transaction->surname); ?></td>
                        </tr>
                        <tr>
                            <th>Mobile Number</th>
                            <td><?php echo esc_html($transaction->mobile_number); ?></td>
                        </tr>
                        <tr>
                            <th>Email Address</th>
                            <td><?php echo esc_html($transaction->email_address); ?></td>
                        </tr>
                        <tr>
                            <th>Amount</th>
                            <td>R<?php echo esc_html($transaction->amount); ?></td>
                        </tr>
                        <tr>
                            <th>Status</th>
                            <td>
                                <span style="color: <?php echo ($transaction->status === 'completed') ? 'green' : (($transaction->status === 'failed') ? 'red' : 'orange'); ?>;">
                                    <?php echo ucfirst(esc_html($transaction->status)); ?>
                                </span>
                            </td>
                        </tr>
                        <tr>
                            <th>Donation Type</th>
                            <td><?php echo esc_html($transaction->donation_type === 'recurring' ? 'Recurring' : 'Once-off'); ?></td>
                        </tr>
                    </tbody>
                </table>
            </section>

            <section class="woocommerce-customer-details">
                <h2>Customer Information</h2>
                <p><strong>Name:</strong> <?php echo esc_html($transaction->name) . ' ' . esc_html($transaction->surname); ?></p>
                <p><strong>Email:</strong> <?php echo esc_html($transaction->email_address); ?></p>
                <p><strong>Mobile:</strong> <?php echo esc_html($transaction->mobile_number); ?></p>
            </section>
        </div>
        <style>
            .woocommerce { font-family: Arial, sans-serif; margin: 0 auto; width: 80%; }
            .woocommerce-order-title { font-size: 24px; font-weight: bold; margin-bottom: 20px; }
            .woocommerce-table th { text-align: left; width: 30%; }
            .woocommerce-table td { text-align: left; }
            .woocommerce-order-details, .woocommerce-customer-details { margin-bottom: 40px; }
            .woocommerce-table { border-collapse: collapse; width: 100%; }
            .woocommerce-table th, .woocommerce-table td { padding: 8px; border-bottom: 1px solid #eee; }
            .woocommerce-table--order-details th { font-weight: bold; }
        </style>
        <?php
    } else {
        echo "<p>No transaction details found for this reference.</p>";
    }
} else {
    echo "<p>Invalid reference number.</p>";
}
