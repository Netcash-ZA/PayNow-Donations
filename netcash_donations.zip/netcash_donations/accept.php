<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
	
	<link rel="icon" href="https://netcash.co.za/wp-content/uploads/2024/11/donation_icon.svg" type="image/svg+xml">
    <title>Netcash Donations - Transaction Successful</title>
    <style>
        body {
            background: radial-gradient(circle, #05b0a8, #7fd3d1);
            color: #333;
            font-family: 'Arial', serif;
            text-align: center;
            line-height: 1.6;
            margin: 0;
            padding: 0;
            display: flex;
            align-items: center;
            justify-content: center;
            min-height: 100vh;
        }

        #pay-invoice {
            max-width: 600px;
            margin: auto;
            padding: 20px;
            border-radius: 10px;
            
            color: #4d4a5b;
            font-family: 'Arial', serif;
			
        }

        .btn {
            background-color: white;
            color: #4d4a5b;
            border: none;
            padding: 12px 20px;
            border-radius: 5px;
            text-decoration: none;
            font-weight: bold;
            transition: background-color 0.3s;
        }

        .btn:hover {
            background-color: #e6e6e6;
        }

        footer {
            margin-top: 20px;
            font-size: 0.9rem;
            color: #666;
        }
.hidden {
    display: none;
}

#party-popper {
    position: fixed;
    top: 30%;
    left: 50%;
    transform: translateX(-50%);
    z-index: 9999;
}




    </style>
</head>
<body>
    <div id="pay-invoice">
        <div class="card-body">
            <div class="card-title">
			
				<img src="https://netcash.co.za/wp-content/uploads/2024/11/donation_icon.svg" style="width: 20%">
                <h2 style="color: #fff; margin-bottom: 15px;">Transaction Successful</h2>
                <p style="font-size: 1.1rem; color: #fff;">
                  Your transaction was approved. Click the "Back to donations" <br> button below to to get redirected.
                </p>
            </div>
            <hr style="border-top: 1px solid #ddd;">

            <div style="text-align: center; margin-top: 20px;">
                <?php
                if ($_SERVER['REQUEST_METHOD'] === 'POST') {
                    $rawData = file_get_contents("php://input");

                    if ($rawData !== false && !empty($rawData)) {
                        $alldata = explode("&", $rawData);
                        $status = explode("=", $alldata[1]);
                        $amount = explode("=", $alldata[8]);
                        $reference = explode("=", $alldata[4]);
                        $method = explode("=", $alldata[9]);

                        $methodNames = array(
                            '1' => 'Credit card',
                            '2' => 'Bank EFT',
                            '3' => 'Retail',
                            '4' => 'Ozow',
                            '5' => 'MasterPass',
                            '6' => 'Visa Checkout',
                            '7' => 'Masterpass QR',
                            '9' => 'Payflex',
                            '10' => 'Flash1Voucher',
                        );

                        $methodName = isset($methodNames[$method[1]]) ? $methodNames[$method[1]] : 'Credit Card';

                        echo "<div style='font-size: 1.1rem; color: #fff; margin-bottom: 10px;'><strong>Status:</strong> " . htmlspecialchars($status[1]) . "</div>";
                        echo "<div style='font-size: 1.1rem; color: #fff; margin-bottom: 10px;'><strong>Amount:</strong> R" . htmlspecialchars($amount[1]) . "</div>";
                        echo "<div style='font-size: 1.1rem; color: #fff; margin-bottom: 10px;'><strong>Reference:</strong> " . htmlspecialchars($reference[1]) . "</div>";
                        echo "<div style='font-size: 1.1rem; color: #fff; margin-bottom: 10px;'><strong>Payment Method:</strong> " . htmlspecialchars($methodName) . "</div>";
                    } else {
                        echo "<div style='color: #4d4a5b; font-size: 1.1rem; margin-top: 20px;'>No data received.</div>";
                    }
                } else {
                    echo "<div style='color: #fff; font-size: 1.1rem; margin-top: 20px;'>No transaction has been processed. Please complete a transaction to view the details.</div>";
                }
                ?>
            </div>
        </div>

      <p style="text-align: center; margin-top: 30px;">
    <a href="#" id="back-to-donations" class="btn">Back to donations</a>
</p>

<script type="text/javascript">
    // JavaScript to redirect to the homepage
    document.getElementById("back-to-donations").onclick = function(event) {
        event.preventDefault();  // Prevent default link behavior
        window.location.href = window.location.origin;  // Redirect to the homepage
    };
</script>
	<script>
		window.onload = function() {
    // Simulate successful payment by showing party poppers as soon as the page loads
    displayPartyPoppers();
};

function displayPartyPoppers() {
    var poppers = document.getElementById('party-popper');
    poppers.classList.remove('hidden');  // Show party poppers
    setTimeout(function() {
        poppers.classList.add('hidden');  // Hide after a few seconds
    }, 60000);  // Show for 5 seconds
}

		
		
		</script>	
		
    </div>

    <footer>
   
    </footer>
</body>
</html>
